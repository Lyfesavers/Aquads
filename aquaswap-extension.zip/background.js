// AquaSwap Extension - Background Service Worker
const DEBUG_LOGS = false;
const dbg = (...args) => { if (DEBUG_LOGS) console.log(...args); };
dbg('🌊 AquaSwap background service worker started');

// Handle extension installation
chrome.runtime.onInstalled.addListener((details) => {
  dbg('Extension installed:', details.reason);
  
  if (details.reason === 'install') {
    // Set default preferences
    chrome.storage.local.set({
      version: '1.4.1',
      installedAt: Date.now(),
      openCount: 0
    }).then(() => {
      dbg('Preferences saved');
      
      // Open welcome page
      chrome.tabs.create({
        url: 'https://aquads.xyz/swap?extension=installed'
      });
    }).catch(err => {
      dbg('Error saving preferences:', err);
    });
  }
});

// Handle messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getStats') {
    chrome.storage.local.get(['openCount', 'lastUsed', 'installedAt']).then(result => {
      sendResponse({ success: true, data: result });
    }).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true; // Keep channel open for async response
  }
  
  if (request.action === 'openFullSite') {
    chrome.tabs.create({ url: 'https://aquads.xyz/swap' });
    sendResponse({ success: true });
    return true;
  }
  
  sendResponse({ success: false, error: 'Unknown action' });
  return true;
});

dbg('✅ AquaSwap background service worker ready');
